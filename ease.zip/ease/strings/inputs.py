this = inputs("Does {} really {} soccer?", "Does my mom really hate soccer?", "{}")
print(this)
            
